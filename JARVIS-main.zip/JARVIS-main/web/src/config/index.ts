const BASE_URL = "http://localhost:8004"

export default BASE_URL